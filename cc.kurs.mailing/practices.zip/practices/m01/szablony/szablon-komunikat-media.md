# KOMUNIKAT PRASOWY - KCZE

**Data:** [data i godzina]
**Kontakt dla mediów:** [rzecznik, tel]

## Co się stało
- [krótki opis zdarzenia]
- [skala i liczby]

## Co robimy
- [działania operacyjne]
- [priorytety]

## Kiedy prąd wróci
- [pierwsza fala]
- [kolejne etapy]

## Instrukcje dla ludności
- [2-3 konkretne zalecenia]

## Aktualizacje
- [gdzie i kiedy będą kolejne komunikaty]
