# NOTATKA DLA MINISTRA MSWiA

**DO:** Minister Spraw Wewnętrznych i Administracji
**OD:** [Imię i nazwisko], KCZE
**DATA:** [data i godzina]
**TEMAT:** Raport z sytuacji kryzysowej - blackout

## 1. SYTUACJA
- [co się stało]
- [skala: liczby, obszary]
- [ryzyko i pilność]

## 2. DZIAŁANIA PODJĘTE
- [ekipy, generatory, paliwo]
- [timeline operacyjny]

## 3. DECYZJE KLUCZOWE
- [priorytety i uzasadnienie]

## 4. RYZYKA I KONSEKWENCJE
- [co może pójść nie tak]
- [skutki społeczne i zdrowotne]

## 5. POTRZEBY OD MSWiA
- [policja / wojsko / logistyka]
- [inne potrzeby]
