# BRIEFING OPERACYJNY - EKIPY TERENOWE

**Data:** [data i godzina]
**Koordynator:** [imię, tel]

## ZASADY OGÓLNE
- Priorytet: CRITICAL > HIGH > MEDIUM
- Generator w szpitalu PRZED restartem ryzykownych podstacji
- Raportuj co 30 min (status, ETA, problemy)

## EKIPY

### EKIPA-01
- **Podstacja:** [ID, adres, GPS]
- **Zadanie:** [restart/naprawa]
- **Priorytet:** [CRITICAL/HIGH/MEDIUM]
- **Wyjazd / ETA:** [godziny]
- **Dependencies:** [jeśli dotyczy]
- **Ryzyko / Plan B:** [jeśli dotyczy]

### EKIPA-02
- **Podstacja:** [ID, adres, GPS]
- **Zadanie:** [restart/naprawa]
- **Priorytet:** [CRITICAL/HIGH/MEDIUM]
- **Wyjazd / ETA:** [godziny]
- **Dependencies:** [jeśli dotyczy]
- **Ryzyko / Plan B:** [jeśli dotyczy]
