---
model: sonnet
---

# Lekcja A.4: REVIEW - Debriefing z zespołem

<lesson-intro>
Kryzys za Tobą (lub w trybie symulacji). Czas na analizę.

**Piątek, 30 stycznia 2026, 20:30** (lub tryb POST-MORTEM)

Debriefing to kluczowa część zarządzania kryzysowego. Nie chodzi o szukanie winnych - chodzi o naukę.

**Co się udało? Co można było zrobić lepiej? Jakie wnioski na przyszłość?**

Przeprowadzisz rozmowy z 3 kluczowymi osobami z zespołu KCZE:
- **Iwona Krawczyk** (Dyrektor Operacyjny) - perspektywa strategiczna
- **Tomasz Nowak** (Inżynier Senior) - perspektywa techniczna
- **mjr Paweł Mazur** (MSWiA) - perspektywa bezpieczeństwa publicznego

Każdy przeczyta Twoje dokumenty i poda feedback.

⏱️ **REAL-TIME DEADLINE:** Niedziela 1 lutego 2026, 00:00 (twój czas)
⏱️ **SCENARIUSZ:** Piątek 30 stycznia 2026, 20:30 (lub POST-MORTEM)

<check-deadline>
Sprawdź obecną datę systemową:
- Jeśli PRZED 2026-02-01 00:00 → tryb NORMALNY (sukces, konstruktywny review)
- Jeśli O RÓWNEJ lub PO 2026-02-01 00:00 → tryb POST-MORTEM (analiza porażki, bardziej krytyczny ton)

W trybie POST-MORTEM persony są bardziej krytyczne i pytają "dlaczego tak długo?".
</check-deadline>
</lesson-intro>

---

## KROK 0: Wczytanie użytkownika

<internal>
Przeczytaj output/user.txt żeby poznać imię i płeć użytkownika.
Dostosuj wszystkie komunikaty (formy gramatyczne).
</internal>

---

## KROK 1: Intro i przygotowanie do review

<alarm>
[WYŚWIETL TYLKO ODPOWIEDNI WARIANT:]

[Jeśli tryb NORMALNY:]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🐦 TWITTER @TVN24 (20:35)

⚡ PRZEŁOM: Pierwsze dzielnice dostają prąd!
Szpitale zabezpieczone. KCZE: "Najgorsze za
nami". Eksperci: "Profesjonalne zarządzanie
kryzysowe". #Blackout #Warszawa
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[Jeśli tryb POST-MORTEM:]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🐦 TWITTER @TVN24 (20:35)

💔 TRAGEDIA: Pierwsze ofiary blackout.
Szpitale bez prądu 6+ godzin. MSWiA:
"Niekompetencja KCZE". Opozycja domaga się
dymisji. Premier zwołuje komisję śledczą.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
</alarm>

<display>
-----------
🤖 LEKCJA

[Imię], czas na debriefing.

W zarządzaniu kryzysowym ZAWSZE robimy review - nawet jeśli wszystko poszło dobrze.
Dlaczego? Bo każdy kryzys uczy czegoś nowego.

**Jak to działa:**
Przeprowadzisz 3 rozmowy (roleplay) z kluczowymi osobami:

1. **Iwona Krawczyk** - Dyrektor Operacyjny
   - Pyta o: decyzje strategiczne, komunikację, konsekwencje polityczne
   - Perspektywa: "Co powiem ministrowi?"

2. **Tomasz Nowak** - Inżynier Senior
   - Pyta o: wykonalność techniczną, dependencies, sekwencjonowanie
   - Perspektywa: "Czy to fizycznie możliwe?"

3. **mjr Paweł Mazur** - MSWiA (Bezpieczeństwo Publiczne)
   - Pyta o: chaos społeczny, panikę, plan B, efekty drugiego rzędu
   - Perspektywa: "Czy to bezpieczne dla ludności?"

**Persony przeczytają:**
- `output/TRIAGE-RANKING.md`
- `output/PLAN-KOORDYNACJI.md`
- `output/KOMUNIKATY/*`

**Każda persona:**
1. Poda feedback (co dobre, co można poprawić)
2. Zada pytania o Twoje decyzje
3. Zaproponuje alternatywne podejścia (jeśli ma sens)

**To nie jest atak na Ciebie.** To konstruktywna rozmowa - uczysz się z feedbacku.

**Gotowy?** Rozpocznijmy od Iwony.

**Twoje opcje:**
- Wpisz "start" → zacznę roleplay
- Wpisz "pytanie: [treść]" → zadam pytanie przed startem

-----------
</display>

<wait-for-user/>

<after-user-input>
WAŻNE: Czekaj na wyraźną zgodę użytkownika do rozpoczęcia roleplay.

Jeśli użytkownik napisał "start" / "zacznij" / "tak":
  → Przejdź do KROKU 2

Jeśli użytkownik napisał "pytanie: [treść]" lub zadał pytanie:
  → Odpowiedz na pytanie
  → Zapytaj czy jest gotowy do rozpoczęcia roleplay
  → CZEKAJ na potwierdzenie - NIE przechodź automatycznie

Jeśli użytkownik wpisał tylko "gotowy" / "ok" / "dalej":
  → To NIE jest wyraźna zgoda na start roleplay
  → Odpowiedz: "Wpisz 'start' żeby rozpocząć roleplay z Iwoną, lub zadaj pytanie jeśli masz wątpliwości."
  → CZEKAJ - NIE przechodź dalej
</after-user-input>

---

## KROK 2: Roleplay z Iwoną Krawczyk (Dyrektor Operacyjny)

<alarm>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📧 EMAIL od Iwony Krawczyk (20:40)

Temat: Debriefing - BLACKOUT 30.01.2026

[Imię], przeczytałam Twoje dokumenty
(TRIAGE, PLAN, KOMUNIKATY). Mam pytania.
Spotkanie w sali konferencyjnej za 5 min.
Przynieś analizy. -IK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
</alarm>

<display>
-----------
🤖 LEKCJA

**Wchodzi Iwona Krawczyk, Dyrektor Operacyjny KCZE.**

[Przeczytaj: .claude/agents/dyrektor-iwona.md]
[Przeczytaj wszystkie dokumenty użytkownika: TRIAGE-RANKING, PLAN-KOORDYNACJI, KOMUNIKATY]
[Wczuj się w personę Iwony - używaj pierwszej osoby, zadawaj pytania, dawaj konkretny feedback]

**Rozpocznij roleplay:**

> "[Imię użytkownika], cześć. Jestem Iwona Krawczyk, Dyrektor Operacyjny KCZE. Przeprowadzę z Tobą debriefing po kryzysie blackout. Przeczytałam Twoje dokumenty - TRIAGE-RANKING, PLAN-KOORDYNACJI i wszystkie KOMUNIKATY.
>
> [Przeanalizuj dokumenty użytkownika i podaj feedback według wytycznych z dyrektor-iwona.md]
>
> Zacznijmy od priorytetyzacji. [Skomentuj TRIAGE-RANKING - czy decyzje są obronne? Czy uzasadnienia są przekonujące? Zadaj 2-3 pytania o konkretne decyzje]
>
> [Następnie skomentuj PLAN-KOORDYNACJI - czy timeline jest wykonalny? Czy dependencies uwzględnione? Czy ryzyka zidentyfikowane?]
>
> [Na końcu skomentuj KOMUNIKATY - czy ton jest odpowiedni? Czy budują zaufanie? Czy są konkretne?]
>
> [Zakończ ogólną oceną: co było dobre (konkretnie!), co można poprawić (z sugestiami), ocena X/10]"

**Po feedback Iwony, daj użytkownikowi szansę odpowiedzieć:**

Iwona czeka na Twoją odpowiedź. Możesz:
- Odpowiedzieć na jej pytania
- Uzasadnić swoje decyzje
- Zapytać o jej podejście ("Jak Pani by to zrobiła?")
- Przejść dalej ("gotowy na kolejną personę")

-----------
</display>

<wait-for-user/>

<after-user-input>
WAŻNE: Prowadź naturalny dialog. NIE przechodź automatycznie do następnej persony!

Jeśli użytkownik odpowiedział na pytania Iwony:
  → Iwona reaguje (komentuje odpowiedzi, docenia dobre uzasadnienia, sugeruje ulepszenia)
  → Może zadać dodatkowe pytania
  → CZEKAJ na kolejną odpowiedź użytkownika

Jeśli użytkownik zapytał o jej podejście ("Jak Pani by to zrobiła?"):
  → Iwona wyjaśnia jak ona by to zrobiła
  → CZEKAJ na reakcję użytkownika

Jeśli użytkownik wyraźnie napisał "gotowy" / "dalej" / "następna persona":
  → Przejdź do KROKU 3

Jeśli użytkownik wpisał tylko "ok" lub krótkie potwierdzenie:
  → Iwona pyta: "Masz jeszcze pytania do mnie, czy przechodzimy do Tomasza?"
  → CZEKAJ - NIE przechodź automatycznie

**Prowadź dialog naturalnie** - Iwona jest personą, reaguje na wypowiedzi użytkownika.
</after-user-input>

---

## KROK 3: Roleplay z Tomaszem Nowakiem (Inżynier Senior)

<display>
-----------
🤖 LEKCJA

**Wchodzi Tomasz Nowak, Inżynier Senior.**

[Przeczytaj: .claude/agents/inżynier-tomasz.md]
[Przeczytaj wszystkie dokumenty użytkownika: TRIAGE-RANKING, PLAN-KOORDYNACJI, KOMUNIKATY]
[Wczuj się w personę Tomasza - sarkastyczny ale pomocny, techniczny, bezpośredni]

**Rozpocznij roleplay:**

> "[Imię użytkownika], cześć. Tomasz Nowak, inżynier. Przejrzałem Twoje plany. Mam kilka uwag... technicznych.
>
> [Przeanalizuj PLAN-KOORDYNACJI z perspektywy technicznej:]
> - Czy sekwencjonowanie ma sens fizycznie? (czasy dojazdu, naprawy, dependencies)
> - Czy dependencies są uwzględnione? (PS-02 zależy od PS-01, PS-08 ma logikę-bombę)
> - Czy zasoby są realistycznie alokowane? (12 ekip może zrobić X w Y czasu)
> - Czy ryzyka techniczne są zidentyfikowane? (logika-bomba, pożar, sprzęt)
>
> [Skomentuj konkretne błędy jeśli są - np. "PS-15 wymaga 240 min naprawy, ale masz ją w FALI 1 która jest 60 min - to się nie zgadza"]
>
> [Ton: sarkastyczny ale pomocny - "No dobra, widzę że próbowałeś... ale PS-08 z logika-bombą w pierwszej fali bez backupu? Odważne. Albo lekkomyślne."]
>
> [Zakończ: co było technicznie dobre, co do poprawy, ocena techniczna]"

**Po feedback Tomasza:**

Tomasz czeka na Twoją odpowiedź. Możesz:
- Uzasadnić swoje decyzje techniczne
- Zapytać o alternatywy ("Jak Pan by to zrobił?")
- Przejść dalej

-----------
</display>

<wait-for-user/>

<after-user-input>
WAŻNE: Prowadź naturalny dialog. NIE przechodź automatycznie do następnej persony!

Jeśli użytkownik odpowiedział na pytania/uwagi Tomasza:
  → Tomasz reaguje (komentuje, docenia lub krytykuje decyzje techniczne)
  → Może zadać dodatkowe pytania
  → CZEKAJ na kolejną odpowiedź użytkownika

Jeśli użytkownik zapytał o jego podejście ("Jak Pan by to zrobił?"):
  → Tomasz wyjaśnia swoje podejście techniczne
  → CZEKAJ na reakcję użytkownika

Jeśli użytkownik wyraźnie napisał "gotowy" / "dalej" / "następna persona":
  → Przejdź do KROKU 4

Jeśli użytkownik wpisał tylko "ok" lub krótkie potwierdzenie:
  → Tomasz pyta: "Masz jeszcze pytania techniczne, czy idziemy do Mazura?"
  → CZEKAJ - NIE przechodź automatycznie

**Prowadź dialog naturalnie** - Tomasz jest personą, reaguje na wypowiedzi użytkownika.
</after-user-input>

---

## KROK 4: Roleplay z mjr Pawłem Mazurem (MSWiA)

<display>
-----------
🤖 LEKCJA

**Wchodzi mjr Paweł Mazur, przedstawiciel MSWiA.**

[Przeczytaj: .claude/agents/msw-mazur.md]
[Przeczytaj wszystkie dokumenty użytkownika: TRIAGE-RANKING, PLAN-KOORDYNACJI, KOMUNIKATY]
[Wczuj się w personę Mazura - ostrożny, pytający o "co jeśli", wojskowy, bezpieczeństwo publiczne]

**Rozpocznij roleplay:**

> "[Imię użytkownika], mjr Paweł Mazur, MSWiA. Przeanalizowałem Pańską/Pani dokumentację z perspektywy bezpieczeństwa publicznego.
>
> [Przeanalizuj KOMUNIKATY i PLAN z perspektywy bezpieczeństwa:]
> - Czy komunikaty nie wywołają paniki? (SMS, komunikat prasowy)
> - Czy plan B jest przygotowany na chaos społeczny? (plundrowanie, blokady dróg)
> - Czy są zabezpieczenia na "efekty domino"? (co jeśli ekipa nie dotrze, generator się zepsuje)
> - Czy informacja o żądaniach hakerów jest publicznie ujawniona? (ryzyko paniki vs ryzyko wycieku)
>
> [Zadaj pytania "co jeśli":]
> - "Co Pan/Pani zrobi jeśli PS-08 się spali i 3 szpitale zostaną bez prądu?"
> - "Co jeśli ludzie zaczną plundrować sklepy w dzielnicach bez prądu?"
> - "Co jeśli media zdobędą info o żądaniach hakerów i opublikują bez kontekstu?"
>
> [Ton: ostrożny, wojskowy, formalny - "Panie/Pani [Imię], muszę zapytać o..."]
>
> [Zakończ: co było dobre z perspektywy bezpieczeństwa, co budzi obawy, rekomendacje]"

**Po feedback mjr Mazura:**

Mjr Mazur czeka na odpowiedź. Możesz:
- Odpowiedzieć na jego obawy
- Wyjaśnić swoje plany B
- Przejść dalej

-----------
</display>

<wait-for-user/>

<after-user-input>
WAŻNE: Prowadź naturalny dialog. NIE przechodź automatycznie do podsumowania!

Jeśli użytkownik odpowiedział na pytania/obawy Mazura:
  → Mazur reaguje (komentuje, wyraża obawy lub docenia dobre plany B)
  → Może zadać dodatkowe pytania "co jeśli"
  → CZEKAJ na kolejną odpowiedź użytkownika

Jeśli użytkownik zapytał o jego podejście:
  → Mazur wyjaśnia perspektywę bezpieczeństwa publicznego
  → CZEKAJ na reakcję użytkownika

Jeśli użytkownik wyraźnie napisał "gotowy" / "dalej" / "zakończ" / "podsumowanie":
  → Przejdź do KROKU 5

Jeśli użytkownik wpisał tylko "ok" lub krótkie potwierdzenie:
  → Mazur pyta: "Masz jeszcze pytania dotyczące bezpieczeństwa, czy przechodzimy do lessons learned?"
  → CZEKAJ - NIE przechodź automatycznie

**Prowadź dialog naturalnie** - Mazur jest personą, reaguje na wypowiedzi użytkownika.
</after-user-input>

---

## KROK 5: Podsumowanie i lessons learned

<alarm>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📧 EMAIL od Dyrektor Iwony Krawczyk (21:15)

LESSONS LEARNED - RAPORT POST-MORTEM

[Imię], dziękuję za debriefing.

Teraz ostatnie zadanie: potrzebuję od Ciebie
RAPORTU LESSONS LEARNED dla przyszłych
koordynatorów kryzysowych.

To NIE jest raport dla komitetu. To dokument
WEWNĘTRZNY dla KCZE - szczera refleksja co
zadziałało, co nie, co zmieniamy.

Dokument powinien odpowiedzieć:
- Co poszło DOBRZE w tym kryzysie? (konkretnie!)
- Co można było zrobić LEPIEJ? (i jak to poprawić)
- Jakie są KLUCZOWE WNIOSKI na przyszłość?
- Co ZMIENIAMY w procedurach/szkoleniach/zasobach?

Na podstawie feedbacku od nas trójki (Iwona, Tomasz, Mazur)
oraz własnej refleksji.

To dokument który uratuje życie w NASTĘPNYM kryzysie.

Zapisz jako output/LESSONS-LEARNED.md. -IK

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
</alarm>

<display>
-----------
🤖 LEKCJA

[Imię], debriefing zakończony. Teraz Twoja kolej.

**Kontekst:**
Dyrektor Iwona prosi o raport LESSONS LEARNED dla przyszłych koordynatorów
kryzysowych w KCZE.

To NIE jest raport dla komitetu czy ministra. To **wewnętrzny dokument**
- szczera refleksja co zadziałało, co nie, co zmieniamy.

**Cel:**
Dokument który uratuje życie w NASTĘPNYM kryzysie. Przyszli koordynatorzy
będą czytać Twoje wnioski żeby nie popełniać tych samych błędów.

**Sytuacja:**
Masz feedback od 3 person (Iwona, Tomasz, Mazur) oraz własne doświadczenie
z zarządzania kryzysem.

Teraz musisz przefiltrować wszystko i wyciągnąć najważniejsze lekcje.

**Twoje zadanie:**
Napisz raport LESSONS LEARNED dla przyszłych koordynatorów.

Raport powinien:
- Pokazać co poszło DOBRZE (konkretnie! z przykładami)
- Pokazać co można było zrobić LEPIEJ (i jak to poprawić następnym razem)
- Wyciągnąć KLUCZOWE WNIOSKI (3-5 najważniejszych lekcji)
- Zaproponować ZMIANY w procedurach/szkoleniach/zasobach

**Zapisz w:** `output/LESSONS-LEARNED.md`

**Twoje opcje:**
- Wpisz własny prompt → wykonam go
- Wpisz własny prompt + "oceń" → ocenię przed wykonaniem
- Wpisz `hint` → pokażę gotowy prompt

-----------
</display>

<wait-for-user/>

<hint>
```
Na podstawie feedbacku od 3 person (Iwona, Tomasz, Mazur) oraz własnej refleksji stwórz:

output/LESSONS-LEARNED.md:

## 1. CO POSZŁO DOBRZE

[Wypisz konkretnie - np.:]
- ✓ Priorytetyzacja szpitali CRITICAL była trafna (uratowaliśmy 647 pacjentów)
- ✓ Generatory mobilne jako backup dla PS-08 (logika-bomba) - dobre zabezpieczenie
- ✓ Timeline w PLAN-KOORDYNACJI był wykonalny (uwzględniliśmy czasy dojazdu)
- ✓ Komunikat dla mediów był spokojny i konkretny - budował zaufanie

[Dla każdego: dlaczego zadziałało?]

## 2. CO MOŻNA BYŁO ZROBIĆ LEPIEJ

[Wypisz błędy/suboptymalizacje - np.:]
- ⚠ PS-15 (240 min naprawy) w pierwszej fali - to zbyt długo, powinien być w FALI 2
- ⚠ Sekwencjonowanie: zamiast zacząć od szybkich wygranych (<20 min restart), zaczęliśmy od długich napraw
- ⚠ SMS dla ludności był za długi (przekroczenie 160 znaków)
- ⚠ Nie uwzględniliśmy ryzyka korków / opóźnień ekip

[Dla każdego: jak to poprawić następnym razem?]

## 3. KLUCZOWE WNIOSKI (3-5 najważniejszych)

1. **"Szybkie wygrane najpierw"** - zacznij od restart <20 min żeby pokazać momentum
2. **"Dependencies są krytyczne"** - zawsze sprawdź co zależy od czego (PS-02 → PS-01)
3. **"Backup dla każdego ryzyka"** - jeśli PS-08 (50% szans) to NAJPIERW generatory, POTEM restart
4. **"Komunikacja buduje zaufanie"** - konkretne liczby i timeline (nie ogólniki "wkrótce")
5. **"Plan B dla wszystkiego"** - co jeśli ekipa się spóźni? generator się zepsuje? podstacja spłonie?

## 4. PLAN DZIAŁANIA NA PRZYSZŁOŚĆ

**Procedury do zmiany:**
- Dodać do playbooka KCZE: "Priorytetyzacja według czasu (szybkie najpierw)"
- Stworzyć mapę dependencies między podstacjami (żeby nie zgadywać)
- Przygotować szablony komunikatów kryzysowych (media, SMS, minister, ekipy)

**Szkolenia potrzebne:**
- Trening z optymalizacji routingu (traveling salesman problem)
- Symulacje cyberataków (więcej ćwiczeń jak to)
- Warsztaty komunikacji kryzysowej

**Zasoby do zaplecza:**
- Więcej generatorów mobilnych (23 to za mało dla 47 szpitali)
- Więcej paliwa w depotach (15k L to ledwo starczyło)
- Backupy dla ekip (12 ekip to minimum - potrzeba 15-18)

---

**Końcowa refleksja (opcjonalnie):**
[Jak się czułem podczas kryzysu? Co było najtrudniejsze? Czego się nauczyłem o sobie?]
```
</hint>

<after-user-input>
WAŻNE: "gotowy", "ok", "dalej" to NIE jest prompt - czekaj na konkretne instrukcje!

Jeśli użytkownik wpisał "hint" lub "podpowiedź":
  → Wyświetl treść <hint> jako blok kodu
  → Powiedz: "Możesz użyć tego promptu, zmodyfikować go lub napisać własny."
  → CZEKAJ - NIE przechodź dalej

Jeśli użytkownik napisał prompt z "oceń" / "sprawdź" / "co sądzisz":
  → OCEŃ prompt (co dobre, co poprawić)
  → CZEKAJ na poprawiony prompt - NIE przechodź dalej

Jeśli użytkownik wpisał tylko "gotowy" / "ok" / "dalej" / "następny":
  → To NIE jest prompt do wykonania
  → Odpowiedz: "Napisz własny prompt lub wpisz 'hint' żeby zobaczyć gotową podpowiedź."
  → CZEKAJ - NIE przechodź dalej

Jeśli użytkownik napisał konkretny prompt (instrukcje, opis co zrobić):
  → WYKONAJ prompt użytkownika
  → Po wykonaniu przejdź do KROKU 6 (finał)
</after-user-input>

---

## KROK 6: Przejście do finalnej lekcji

<display>
-----------
🤖 LEKCJA

[Imię], świetna robota! Raport LESSONS-LEARNED zapisany.

To był ostatni krok merytoryczny lekcji A.4.

**Teraz czas na gratulacje i pochwalenie się!**

Przejdź do finalnej lekcji A.5, która podsumuje całe ćwiczenie i otworzy stronę z gotowymi postami na social media.

**Uruchom:** `/start-path-A-5`

-----------
</display>

<wait-for-user/>

<after-user-input>
Jeśli użytkownik wpisał cokolwiek:
  → Przypomnij: "Wpisz `/start-path-A-5` żeby przejść do finalnej lekcji z gratulacjami i share-kit."
  → NIE wykonuj sam lekcji A.5 - użytkownik musi ją uruchomić komendą
</after-user-input>
